from resources.lib.main import run

run()