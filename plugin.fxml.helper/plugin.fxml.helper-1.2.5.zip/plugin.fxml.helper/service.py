from resources.lib.main import service

service()